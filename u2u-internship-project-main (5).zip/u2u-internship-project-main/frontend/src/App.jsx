import React, { useState, useEffect } from 'react';

// Backend base URL used by every fetch call in this file
const API_BASE = "http://127.0.0.1:8000";

function App() {
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false); // New: Track loading
  const [error, setError] = useState(""); // New: Track errors

  // --- TASK 5: Conversation History state ---
  // `history` holds every past exchange returned by GET /api/history
  // (each item looks like { user_prompt, ai_response, timestamp }).
  // We keep it as one flat list, ordered oldest -> newest, and simply
  // append the new exchange to the end after every successful /api/chat call.
  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [historyError, setHistoryError] = useState("");

  // --- TASK 5: Fetch existing conversation history once, when the page loads ---
  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/history`);
        if (!res.ok) {
          throw new Error("Failed to load conversation history.");
        }
        const data = await res.json();
        // Backend returns { history: [{ user_prompt, ai_response, timestamp }, ...] }
        setHistory(data.history || []);
      } catch (err) {
        // Non-fatal: the user can still start a new conversation even if
        // past history couldn't be loaded (e.g. backend just started).
        setHistoryError("Could not load previous conversations.");
      } finally {
        setHistoryLoading(false);
      }
    };

    fetchHistory();
  }, []); // empty dependency array = run once on mount

  const handleSubmit = async () => {
    if (!prompt.trim()) return;

    // Reset states before new request
    setIsLoading(true);
    setError("");

    const currentPrompt = prompt;
    setPrompt("");

    try {
      const res = await fetch(`${API_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: currentPrompt })
      });

      // If server returns an error (e.g., 500), throw an exception
      if (!res.ok) {
        throw new Error("Server failed to respond. Please try again.");
      }

      const data = await res.json();

      // --- TASK 5: append this new exchange to the displayed history ---
      // The backend already saved it to conversation_history in SQLite;
      // here we just mirror that in local state so the UI updates
      // immediately without needing to re-fetch /api/history.
      setHistory((prev) => [
        ...prev,
        {
          user_prompt: currentPrompt,
          ai_response: data.response,
          timestamp: new Date().toISOString()
        }
      ]);
    } catch (err) {
      // Handle connection errors or server failures
      setError("Unable to connect to the AI service. Is the backend running?");
    } finally {
      setIsLoading(false); // Stop loading spinner
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Cybersecurity Incident Agent</h1>

      <textarea 
        value={prompt} 
        onChange={(e) => setPrompt(e.target.value)} 
        placeholder="Enter incident details..."
        disabled={isLoading} // Disable input while loading
      />

      <div style={{ marginTop: '10px' }}>
        <button onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? "Analyzing..." : "Submit"}
        </button>
      </div>

      {/* Show Error Message if one exists */}
      {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}
      {historyError && <div style={{ color: 'orange', marginTop: '10px' }}>{historyError}</div>}

      {/* --- TASK 5: Conversation History display, oldest first --- */}
      <div style={{ marginTop: '20px' }}>
        <h3>Conversation History</h3>

        {historyLoading && <div style={{ color: '#888' }}>Loading previous conversations...</div>}

        {!historyLoading && history.length === 0 && (
          <div style={{ color: '#888' }}>No previous conversations yet. Describe an incident to get started.</div>
        )}

        {history.map((entry, idx) => (
          <div
            key={idx}
            style={{ marginTop: '10px', border: '1px solid #ccc', padding: '10px' }}
          >
            <div style={{ backgroundColor: '#f5f5f5', padding: '8px', marginBottom: '6px' }}>
              <strong>You:</strong> {entry.user_prompt}
            </div>
            <div style={{ padding: '8px' }}>
              <strong>AI Analysis:</strong> {entry.ai_response}
            </div>
            {entry.timestamp && (
              <div style={{ fontSize: '12px', color: '#999', marginTop: '4px' }}>
                {new Date(entry.timestamp).toLocaleString()}
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div style={{ marginTop: '10px', color: '#888' }}>Analyzing...</div>
        )}
      </div>
    </div>
  );
}

export default App;
