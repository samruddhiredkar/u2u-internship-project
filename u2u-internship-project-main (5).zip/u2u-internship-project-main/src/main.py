import os
import json
import sqlite3
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from groq import Groq

# Load environment variables
load_dotenv()

app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Groq client
api_key = os.getenv("GROQ_API_KEY")
if not api_key:
    raise RuntimeError("GROQ_API_KEY not found.")
client = Groq(api_key=api_key)

# --- FIX 1: Corrected Database Path ---
def get_db_connection():
    return sqlite3.connect('deployment/incident_response.db')

# =========================================================================
# TASK 5: CONVERSATION HISTORY
# Every /api/chat exchange (user prompt + AI response + timestamp) is
# persisted to the existing SQLite database (deployment/incident_response.db)
# so the conversation survives server restarts and page refreshes.
# =========================================================================

def init_history_table():
    """
    Creates the `conversation_history` table the first time the app starts,
    if it doesn't already exist. Uses the same SQLite file as the rest of
    the project (incident_response.db) so no new database is introduced.

    Columns:
      id           - auto-incrementing primary key, also used for ordering
      user_prompt  - the analyst's message
      ai_response  - the AI's reply to that message
      timestamp    - UTC ISO-8601 timestamp of when the exchange happened
    """
    conn = get_db_connection()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS conversation_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_prompt TEXT NOT NULL,
                ai_response TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
            """
        )
        conn.commit()
    finally:
        conn.close()

# Run once at startup so the table is guaranteed to exist before any
# request hits /api/chat or /api/history.
init_history_table()


def save_conversation(user_prompt: str, ai_response: str) -> None:
    """
    Inserts one completed exchange (prompt + response + timestamp) into
    conversation_history. Called after every successful /api/chat call.
    Wrapped in try/except so a database hiccup never breaks the chat
    response the user is waiting on.
    """
    try:
        conn = get_db_connection()
        conn.execute(
            "INSERT INTO conversation_history (user_prompt, ai_response, timestamp) VALUES (?, ?, ?)",
            (user_prompt, ai_response, datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        # Logged, not raised: failing to save history shouldn't fail the chat request.
        print(f"Warning: failed to save conversation history: {e}")


def get_all_conversations():
    """
    Returns every stored exchange in chronological order (oldest first),
    formatted for direct use by the frontend.
    """
    conn = get_db_connection()
    cur = conn.execute(
        "SELECT user_prompt, ai_response, timestamp FROM conversation_history ORDER BY id ASC"
    )
    rows = cur.fetchall()
    conn.close()
    return [
        {"user_prompt": r[0], "ai_response": r[1], "timestamp": r[2]}
        for r in rows
    ]

# Utility to load knowledge base
def load_data(filename):
    try:
        with open(f'data/{filename}', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Load data into global memory
PLAYBOOKS = load_data('playbooks.json')
CVE_DATA = load_data('cve_data.json')

# Models
class ChatRequest(BaseModel):
    prompt: str

class FeedbackRequest(BaseModel):
    incident_id: str
    rating: int

@app.get("/api/health")
def health_check():
    try:
        conn = get_db_connection()
        conn.close()
        return {"status": "healthy", "database": "connected"}
    except:
        return {"status": "error", "database": "disconnected"}

@app.post("/api/chat")
async def chat(request: ChatRequest):
    # 1. Handle Missing Parameters / Invalid Requests (Client-Side Errors)
    # Checks if the prompt is empty or just whitespace
    if not request.prompt or not request.prompt.strip():
        raise HTTPException(
            status_code=400, 
            detail="Prompt required. Request payload cannot be empty."
        )
        
    try:
        # Access the list inside the playbooks memory object
        playbook_list = PLAYBOOKS.get("playbooks", []) if isinstance(PLAYBOOKS, dict) else PLAYBOOKS
        
        system_instructions = (
            "You are a Cybersecurity Assistant. "
            f"Reference Playbooks: {json.dumps(playbook_list[:10])}. " 
            f"Reference CVE Data: {json.dumps(CVE_DATA)}. "
            "Provide specific, actionable steps based on these data sources."
        )
        
        # API Call wrapped in a timeout/error check layer
        import groq
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_instructions},
                {"role": "user", "content": request.prompt}
            ],
            model="llama-3.1-8b-instant",
            timeout=15.0 # 2. Handle Timeout Conditions (Stops hanging if API is slow)
        )

        ai_response = chat_completion.choices[0].message.content

        # --- TASK 5: save this exchange (prompt + response + timestamp) ---
        save_conversation(request.prompt, ai_response)

        return {
            "response": ai_response,
            "incident_type": "analyzed_by_ai"
        }
        
    except groq.APIStatusError as e:
        # 3. Handle Specific Invalid API Keys or Bad Request configurations
        print(f"Groq API Error: {e.status_code} - {e.message}")
        raise HTTPException(status_code=e.status_code, detail=f"AI Service Error: {e.message}")
        
    except Exception as e:
        # 4. Handle Unexpected Server Errors 
        print(f"Server Error: {e}")
        raise HTTPException(status_code=500, detail="An internal server error occurred while communicating with the AI service.")

@app.get("/api/history")
def history():
    """
    TASK 5: Returns every stored conversation exchange, oldest first, so the
    frontend can render the full chat history in order on page load.
    """
    try:
        return {"history": get_all_conversations()}
    except Exception as e:
        print(f"Server Error fetching history: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve conversation history.")

@app.get("/api/users")
def users():
    return {"users": ["Analyst_1", "Analyst_2"]}

@app.post("/api/feedback")
def feedback(payload: FeedbackRequest):
    return {"status": "logged", "received_rating": payload.rating}

